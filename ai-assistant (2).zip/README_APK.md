# 📱 Sia AI Assistant - 1-Click APK Generator

इस प्रोजेक्ट में APK बनाने का पूरा कोड और ऑटोमेशन पहले से शामिल है। आपको अलग से कुछ भी नहीं जोड़ना है।

## 🚀 तरीका 1: GitHub पर अपलोड करके सीधा APK पाएं (सबसे आसान)

1. इस पूरे फोल्डर (ZIP) को GitHub पर नई रिपॉजिटरी में अपलोड (Upload files) या `git push` कर दें।
2. GitHub अपने आप **`.github/workflows/build-apk.yml`** चलाएगा।
3. 2 मिनट में:
   - **Releases** सेक्शन में सीधे **`Sia-AI-Assistant.apk`** डाउनलोड लिंक मिल जाएगा।
   - या **Actions** टैब में जाकर **`Sia-AI-Assistant-APK`** डाउनलोड कर सकते हैं।

---

## 💻 तरीका 2: अपने कंप्यूटर पर 1-क्लिक में APK बनाएं

- **Windows पर**: बस `build-apk.bat` पर डबल क्लिक करें।
- **Mac / Linux पर**: टर्मिनल में `./build-apk.sh` चलाएं।

APK फाइल यहां बन जाएगी: `app/build/outputs/apk/debug/app-debug.apk`
