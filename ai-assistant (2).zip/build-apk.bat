@echo off
echo ==========================================
echo 🚀 Building Sia AI Assistant APK on Windows...
echo ==========================================

if not exist .env (
    if exist .env.example (
        copy .env.example .env >nul
    ) else (
        type nul > .env
    )
)

call gradlew.bat assembleDebug --no-daemon

echo.
echo ==========================================
echo ✅ BUILD SUCCESSFUL!
echo APK is at: app\build\outputs\apk\debug\app-debug.apk
echo ==========================================
pause
