package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.example.service.AiAssistantOverlayService
import com.example.ui.MainScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private var hasOverlayPermission by mutableStateOf(false)
    private var hasMicPermission by mutableStateOf(false)
    private var hasNotificationPermission by mutableStateOf(false)

    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasMicPermission = permissions[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            hasNotificationPermission = permissions[Manifest.permission.POST_NOTIFICATIONS] == true ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else {
            hasNotificationPermission = true
        }

        // If overlay permission is not yet granted, guide user to overlay settings
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
        } else {
            hasOverlayPermission = true
            startOverlayService()
        }
    }

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        hasOverlayPermission = Settings.canDrawOverlays(this)
        if (hasOverlayPermission) {
            Toast.makeText(this, "Overlay Permission Granted! Sia Assistant Ready.", Toast.LENGTH_SHORT).show()
            startOverlayService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        refreshPermissions()

        // As requested by user: on opening the app, immediately ask for all required permissions!
        requestAllPermissions()

        setContent {
            MyApplicationTheme {
                MainScreen(
                    hasOverlayPermission = hasOverlayPermission,
                    hasMicPermission = hasMicPermission,
                    hasNotificationPermission = hasNotificationPermission,
                    onRequestAllPermissions = { requestAllPermissions() },
                    onRequestOverlayPermission = { requestOverlayPermission() },
                    onStartService = { startOverlayService() },
                    onStopService = { stopOverlayService() },
                    onUpdateConfig = { updateServiceConfig() },
                    onMinimizeApp = {
                        moveTaskToBack(true)
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermissions()
    }

    private fun refreshPermissions() {
        hasOverlayPermission = Settings.canDrawOverlays(this)
        hasMicPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        hasNotificationPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun requestAllPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        if (!hasMicPermission) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.CAMERA)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (permissionsToRequest.isNotEmpty()) {
            requestPermissionsLauncher.launch(permissionsToRequest.toTypedArray())
        } else if (!hasOverlayPermission) {
            requestOverlayPermission()
        } else {
            startOverlayService()
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Please enable 'Allow display over other apps' so Sia Assistant can stay on your screen",
                Toast.LENGTH_LONG
            ).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        } else {
            hasOverlayPermission = true
            startOverlayService()
        }
    }

    private fun startOverlayService() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }

        val serviceIntent = Intent(this, AiAssistantOverlayService::class.java).apply {
            action = AiAssistantOverlayService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun stopOverlayService() {
        val serviceIntent = Intent(this, AiAssistantOverlayService::class.java).apply {
            action = AiAssistantOverlayService.ACTION_STOP
        }
        startService(serviceIntent)
    }

    private fun updateServiceConfig() {
        val serviceIntent = Intent(this, AiAssistantOverlayService::class.java).apply {
            action = AiAssistantOverlayService.ACTION_UPDATE_CONFIG
        }
        if (AiAssistantOverlayService.isServiceRunning) {
            startService(serviceIntent)
        }
    }
}

