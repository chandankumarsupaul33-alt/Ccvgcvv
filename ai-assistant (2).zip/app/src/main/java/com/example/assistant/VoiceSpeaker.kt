package com.example.assistant

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Manages Text-To-Speech with optimized sweet female voice profile in Hindi and English.
 */
class VoiceSpeaker(context: Context) {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private val completionCallbacks = java.util.concurrent.ConcurrentHashMap<String, () -> Unit>()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _pitch = MutableStateFlow(1.25f) // Sweet, youthful female pitch
    val pitch: StateFlow<Float> = _pitch.asStateFlow()

    private val _speechRate = MutableStateFlow(1.0f)
    val speechRate: StateFlow<Float> = _speechRate.asStateFlow()

    private val _currentVoiceName = MutableStateFlow("Default Female")
    val currentVoiceName: StateFlow<String> = _currentVoiceName.asStateFlow()

    init {
        initializeTts()
    }

    private fun initializeTts() {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isInitialized = true
                configureFemaleVoice()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                        if (utteranceId != null) {
                            completionCallbacks.remove(utteranceId)?.invoke()
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                        if (utteranceId != null) {
                            completionCallbacks.remove(utteranceId)
                        }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        _isSpeaking.value = false
                        if (utteranceId != null) {
                            completionCallbacks.remove(utteranceId)
                        }
                        Log.e("VoiceSpeaker", "TTS error code: $errorCode")
                    }
                })
            } else {
                Log.e("VoiceSpeaker", "Failed to initialize TextToSpeech: $status")
            }
        }
    }

    /**
     * Finds and applies the best female voice available on the device.
     */
    private fun configureFemaleVoice() {
        val engine = tts ?: return
        try {
            // First prefer Hindi locale if available, else Indian English or US English
            val hindiLocale = Locale("hi", "IN")
            val indianEnglish = Locale("en", "IN")

            val hindiSupported = engine.isLanguageAvailable(hindiLocale) >= TextToSpeech.LANG_AVAILABLE
            val targetLocale = if (hindiSupported) hindiLocale else indianEnglish
            engine.language = targetLocale

            // Scan available voices for female attributes
            val voices: Set<Voice>? = engine.voices
            var selectedVoice: Voice? = null

            if (!voices.isNullOrEmpty()) {
                // Priority 1: Female voice in hi-IN or en-IN
                selectedVoice = voices.firstOrNull { voice ->
                    val name = voice.name.lowercase(Locale.ROOT)
                    val isFemale = name.contains("female") || name.contains("woman") || name.contains("#female")
                    val isTargetLang = voice.locale.language == "hi" || (voice.locale.language == "en" && voice.locale.country == "IN")
                    isFemale && isTargetLang && !voice.isNetworkConnectionRequired
                }

                // Priority 2: Any female voice
                if (selectedVoice == null) {
                    selectedVoice = voices.firstOrNull { voice ->
                        val name = voice.name.lowercase(Locale.ROOT)
                        (name.contains("female") || name.contains("woman")) && !voice.isNetworkConnectionRequired
                    }
                }

                // Priority 3: Any Indian voice (high pitch makes it melodious female)
                if (selectedVoice == null) {
                    selectedVoice = voices.firstOrNull { voice ->
                        voice.locale.language == "hi" || voice.locale.country == "IN"
                    }
                }

                if (selectedVoice != null) {
                    engine.voice = selectedVoice
                    _currentVoiceName.value = selectedVoice.name
                }
            }

            // Set high pitch to produce a pleasant, sweet female tone
            engine.setPitch(_pitch.value)
            engine.setSpeechRate(_speechRate.value)
        } catch (e: Exception) {
            Log.e("VoiceSpeaker", "Error configuring female voice", e)
        }
    }

    fun setPitch(value: Float) {
        _pitch.value = value
        tts?.setPitch(value)
    }

    fun setSpeechRate(value: Float) {
        _speechRate.value = value
        tts?.setSpeechRate(value)
    }

    fun speak(text: String, onComplete: (() -> Unit)? = null) {
        if (!isInitialized || tts == null) {
            Log.w("VoiceSpeaker", "TTS not initialized yet")
            return
        }

        try {
            // Apply current parameters
            tts?.setPitch(_pitch.value)
            tts?.setSpeechRate(_speechRate.value)

            val utteranceId = "sia_utterance_${System.currentTimeMillis()}"
            if (onComplete != null) {
                completionCallbacks[utteranceId] = onComplete
            }
            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            }

            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        } catch (e: Exception) {
            Log.e("VoiceSpeaker", "Error speaking text", e)
            _isSpeaking.value = false
        }
    }

    fun stop() {
        try {
            tts?.stop()
            _isSpeaking.value = false
        } catch (e: Exception) {
            Log.e("VoiceSpeaker", "Error stopping TTS", e)
        }
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
            isInitialized = false
        } catch (e: Exception) {
            Log.e("VoiceSpeaker", "Error shutting down TTS", e)
        }
    }
}
