package com.example.assistant

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AssistantPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("sia_assistant_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_HIDDEN_MODE = "key_hidden_mode"
        private const val KEY_ALWAYS_LISTENING = "key_always_listening"
        private const val KEY_HIDE_LAUNCHER_ICON = "key_hide_launcher_icon"
        private const val KEY_VOICE_PITCH = "key_voice_pitch"
        private const val KEY_VOICE_RATE = "key_voice_rate"

        @Volatile
        private var instance: AssistantPreferences? = null

        fun getInstance(context: Context): AssistantPreferences {
            return instance ?: synchronized(this) {
                instance ?: AssistantPreferences(context.applicationContext).also { instance = it }
            }
        }
    }

    private val _hiddenMode = MutableStateFlow(prefs.getBoolean(KEY_HIDDEN_MODE, true))
    val hiddenMode: StateFlow<Boolean> = _hiddenMode.asStateFlow()

    private val _alwaysListening = MutableStateFlow(prefs.getBoolean(KEY_ALWAYS_LISTENING, true))
    val alwaysListening: StateFlow<Boolean> = _alwaysListening.asStateFlow()

    private val _hideLauncherIcon = MutableStateFlow(prefs.getBoolean(KEY_HIDE_LAUNCHER_ICON, false))
    val hideLauncherIcon: StateFlow<Boolean> = _hideLauncherIcon.asStateFlow()

    private val _pitch = MutableStateFlow(prefs.getFloat(KEY_VOICE_PITCH, 1.25f))
    val pitch: StateFlow<Float> = _pitch.asStateFlow()

    private val _speechRate = MutableStateFlow(prefs.getFloat(KEY_VOICE_RATE, 1.0f))
    val speechRate: StateFlow<Float> = _speechRate.asStateFlow()

    fun setHiddenMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_HIDDEN_MODE, enabled).apply()
        _hiddenMode.value = enabled
    }

    fun setAlwaysListening(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ALWAYS_LISTENING, enabled).apply()
        _alwaysListening.value = enabled
    }

    fun setHideLauncherIcon(context: Context, hide: Boolean) {
        prefs.edit().putBoolean(KEY_HIDE_LAUNCHER_ICON, hide).apply()
        _hideLauncherIcon.value = hide

        try {
            val componentName = ComponentName(context.packageName, "${context.packageName}.LauncherAlias")
            val newState = if (hide) {
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            } else {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            }
            context.packageManager.setComponentEnabledSetting(
                componentName,
                newState,
                PackageManager.DONT_KILL_APP
            )
        } catch (e: Exception) {
            Log.e("AssistantPrefs", "Error updating launcher alias component setting", e)
        }
    }

    fun setPitch(pitch: Float) {
        prefs.edit().putFloat(KEY_VOICE_PITCH, pitch).apply()
        _pitch.value = pitch
    }

    fun setSpeechRate(rate: Float) {
        prefs.edit().putFloat(KEY_VOICE_RATE, rate).apply()
        _speechRate.value = rate
    }
}
