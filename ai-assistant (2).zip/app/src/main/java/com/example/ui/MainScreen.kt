package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import com.example.assistant.AssistantPreferences
import com.example.assistant.AssistantBrain
import com.example.assistant.VoiceRecognizer
import com.example.assistant.VoiceSpeaker
import com.example.service.AiAssistantOverlayService
import com.example.ui.theme.ElectricMagenta
import com.example.ui.theme.NeonCyan

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    hasOverlayPermission: Boolean,
    hasMicPermission: Boolean,
    hasNotificationPermission: Boolean,
    onRequestAllPermissions: () -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onStartService: () -> Unit,
    onStopService: () -> Unit,
    onUpdateConfig: () -> Unit = {},
    onMinimizeApp: () -> Unit
) {
    val context = LocalContext.current
    val preferences = remember { AssistantPreferences.getInstance(context) }
    val hiddenMode by preferences.hiddenMode.collectAsState()
    val alwaysListening by preferences.alwaysListening.collectAsState()
    val hideLauncherIcon by preferences.hideLauncherIcon.collectAsState()
    val voiceSpeaker = remember { VoiceSpeaker(context) }
    val assistantBrain = remember { AssistantBrain(context) }

    var inAppListening by remember { mutableStateOf(false) }
    var inAppUserPrompt by remember { mutableStateOf("") }
    var inAppAiResponse by remember { mutableStateOf("Namaste! Main Sia hoon. Main aapki kya madad kar sakti hoon?") }
    var inAppRms by remember { mutableFloatStateOf(0f) }

    val voiceRecognizer = remember {
        VoiceRecognizer(
            context = context,
            onResult = { result ->
                inAppListening = false
                inAppUserPrompt = result
                val brainResponse = assistantBrain.processCommand(result)
                inAppAiResponse = brainResponse.displayText
                voiceSpeaker.speak(brainResponse.spokenText)
            },
            onError = {
                inAppListening = false
            }
        )
    }

    val isSpeaking by voiceSpeaker.isSpeaking.collectAsState()
    val speakerPitch by voiceSpeaker.pitch.collectAsState()
    val speakerRate by voiceSpeaker.speechRate.collectAsState()

    var overlayServiceRunning by remember { mutableStateOf(AiAssistantOverlayService.isServiceRunning) }

    val allPermissionsGranted = hasOverlayPermission && hasMicPermission && hasNotificationPermission

    val infiniteTransition = rememberInfiniteTransition(label = "hero_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "hero_scale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070A12))
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Hero Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Glowing Avatar
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .scale(if (isSpeaking || inAppListening) pulseScale else 1f),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(110.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(
                                        if (inAppListening) NeonCyan.copy(alpha = 0.5f)
                                        else if (isSpeaking) ElectricMagenta.copy(alpha = 0.5f)
                                        else Color(0xFF7C3AED).copy(alpha = 0.35f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )

                    Image(
                        painter = painterResource(id = R.drawable.ic_assistant_avatar),
                        contentDescription = "Sia Avatar",
                        modifier = Modifier
                            .size(86.dp)
                            .clip(CircleShape)
                            .border(
                                2.5.dp,
                                Brush.linearGradient(listOf(NeonCyan, ElectricMagenta)),
                                CircleShape
                            )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Sia AI Assistant",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "Sweet Female Voice • Background Floating Assistant",
                    color = Color(0xFF38BDF8),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Permissions Status Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .testTag("permissions_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (allPermissionsGranted) Color(0xFF0F1E2C) else Color(0xFF1E1428)
            ),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.linearGradient(
                    if (allPermissionsGranted) listOf(Color(0xFF059669), Color(0xFF10B981))
                    else listOf(Color(0xFFE11D48), Color(0xFFF43F5E))
                ),
                width = 1.dp
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (allPermissionsGranted) "Sabhi Permissions Active Hai ✅" else "Permissions Zaroori Hai ⚠️",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (allPermissionsGranted) Color(0x3310B981) else Color(0x33F43F5E)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (allPermissionsGranted) "Ready" else "Action Needed",
                            color = if (allPermissionsGranted) Color(0xFF34D399) else Color(0xFFFB7185),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Permission item rows
                PermissionItem(
                    title = "Screen Overlay (Display over other apps)",
                    subtitle = "App cut hone ke baad bhi home screen par bubble dikhega",
                    isGranted = hasOverlayPermission,
                    icon = Icons.Default.Layers,
                    onClick = onRequestOverlayPermission
                )

                PermissionItem(
                    title = "Microphone (Aapki aawaz sunne ke liye)",
                    subtitle = "Jo bhi bolein use recognize karne ke liye",
                    isGranted = hasMicPermission,
                    icon = Icons.Default.Mic,
                    onClick = onRequestAllPermissions
                )

                PermissionItem(
                    title = "Notifications & Foreground Service",
                    subtitle = "Background me 24/7 AI assistant active rakhne ke liye",
                    isGranted = hasNotificationPermission,
                    icon = Icons.Default.Notifications,
                    onClick = onRequestAllPermissions
                )

                if (!allPermissionsGranted) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onRequestAllPermissions,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("grant_all_permissions_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricMagenta
                        )
                    ) {
                        Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Sabhi Permissions Grant Karein", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // AI Assistant Master Control & Hidden Mode Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .testTag("floating_assistant_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (hiddenMode) Color(0xFF13152C) else Color(0xFF131B2E)
            ),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.linearGradient(
                    if (hiddenMode) listOf(ElectricMagenta, Color(0xFF7C3AED))
                    else listOf(NeonCyan, Color(0xFF7C3AED))
                ),
                width = 1.4.dp
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Service Master Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "AI Assistant Service",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (overlayServiceRunning) "बैकग्राउंड में एक्टिव है ⚡" else "सर्विस बंद है",
                            color = if (overlayServiceRunning) NeonCyan else Color(0xFF94A3B8),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Switch(
                        checked = overlayServiceRunning,
                        onCheckedChange = { isChecked ->
                            if (isChecked) {
                                if (hasOverlayPermission) {
                                    onStartService()
                                    overlayServiceRunning = true
                                    onUpdateConfig()
                                } else {
                                    onRequestOverlayPermission()
                                }
                            } else {
                                onStopService()
                                overlayServiceRunning = false
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = NeonCyan,
                            uncheckedThumbColor = Color(0xFF64748B),
                            uncheckedTrackColor = Color(0xFF1E293B)
                        ),
                        modifier = Modifier.testTag("floating_assistant_switch")
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color(0xFF1E293B))
                )
                Spacer(modifier = Modifier.height(14.dp))

                // Hidden Mode Toggle (USER REQUEST: Home screen par icon nahi dikhega, bas chhupa hoga)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (hiddenMode) Color(0x33EC4899) else Color(0x221E293B))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(if (hiddenMode) ElectricMagenta else Color(0xFF334155)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (hiddenMode) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "आइकॉन छिपाएं (Hidden Mode)",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (hiddenMode) "होम स्क्रीन पर कोई आइकॉन नहीं दिखेगा (पूरी तरह छुपा हुआ)"
                                else "होम स्क्रीन पर तैरता हुआ बबल दिखेगा",
                                color = if (hiddenMode) Color(0xFFF9A8D4) else Color(0xFF94A3B8),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Switch(
                        checked = hiddenMode,
                        onCheckedChange = { isChecked ->
                            preferences.setHiddenMode(isChecked)
                            onUpdateConfig()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = ElectricMagenta,
                            uncheckedThumbColor = Color(0xFF64748B),
                            uncheckedTrackColor = Color(0xFF1E293B)
                        ),
                        modifier = Modifier.testTag("hidden_mode_switch")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Always Listening Toggle (USER REQUEST: kuch bhi bolenge wo bhi bolega sab kuch)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (alwaysListening) Color(0x3306B6D4) else Color(0x221E293B))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(if (alwaysListening) NeonCyan else Color(0xFF334155)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Hearing,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "ऑलवेज लिसनिंग (Always Listen)",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (alwaysListening) "बैकग्राउंड में सुन रही है • आप बस बोलें!"
                                else "मैन्युअल टैप करने पर सुनेगी",
                                color = if (alwaysListening) NeonCyan else Color(0xFF94A3B8),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Switch(
                        checked = alwaysListening,
                        onCheckedChange = { isChecked ->
                            preferences.setAlwaysListening(isChecked)
                            onUpdateConfig()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = NeonCyan,
                            uncheckedThumbColor = Color(0xFF64748B),
                            uncheckedTrackColor = Color(0xFF1E293B)
                        ),
                        modifier = Modifier.testTag("always_listening_switch")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Hide App Launcher Icon Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (hideLauncherIcon) Color(0x33A855F7) else Color(0x221E293B))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(if (hideLauncherIcon) Color(0xFFA855F7) else Color(0xFF334155)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (hideLauncherIcon) Icons.Default.VisibilityOff else Icons.Default.Layers,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "ऐप लॉन्चर आइकॉन छुपाएं",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (hideLauncherIcon) "होम स्क्रीन / ऐप मेनू से ऐप का आइकॉन छुप गया है (नोटिफिकेशन से खोलें)"
                                else "होम स्क्रीन पर ऐप का आइकॉन दिखेगा",
                                color = if (hideLauncherIcon) Color(0xFFD8B4FE) else Color(0xFF94A3B8),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Switch(
                        checked = hideLauncherIcon,
                        onCheckedChange = { isChecked ->
                            preferences.setHideLauncherIcon(context, isChecked)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFFA855F7),
                            uncheckedThumbColor = Color(0xFF64748B),
                            uncheckedTrackColor = Color(0xFF1E293B)
                        ),
                        modifier = Modifier.testTag("hide_launcher_icon_switch")
                    )
                }

                if (overlayServiceRunning) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (hiddenMode) Color(0xFF1E1430) else Color(0xFF0F2636))
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (hiddenMode) "🕵️‍♂️ हिडन मोड चालू है (Zero Icon on Screen)"
                                    else "🔮 फ्लोटिंग बबल स्क्रीन पर लाइव है",
                                    color = if (hiddenMode) Color(0xFFF472B6) else NeonCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (hiddenMode) {
                                    "एप्लीकेशन पूरा कट (Home button) करने के बाद भी स्क्रीन पर कोई आइकॉन नहीं दिखेगा। बैकग्राउंड में सिया पूरी तरह छुपी रहेगी और जो भी बोलेंगे सब कुछ करेगी और मीठी आवाज़ में जवाब देगी!"
                                } else {
                                    "स्क्रीन पर सिया का फ्लोटिंग गोल आइकॉन रहेगा जिसे आप स्क्रीन पर कहीं भी ले जा सकते हैं या टैप करके बात कर सकते हैं।"
                                },
                                color = Color(0xFFE2E8F0),
                                fontSize = 12.sp,
                                lineHeight = 17.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = onMinimizeApp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(42.dp)
                                    .testTag("test_minimize_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (hiddenMode) Color(0xFFBE185D) else Color(0xFF0284C7)
                                )
                            ) {
                                Text("App Cut Karke Bol Kar Dekhein 🏠🎙️", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Best Female Voice Customizer ("Best Ladki Voice")
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .testTag("voice_settings_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161928)),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.linearGradient(listOf(ElectricMagenta, Color(0xFFF43F5E))),
                width = 1.dp
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.RecordVoiceOver,
                        contentDescription = null,
                        tint = ElectricMagenta,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Best Ladki Voice Settings 👩✨",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Pitch Slider (Female Voice Tone)
                Text(
                    text = "Aawaz ki Sweetness (Pitch: ${(speakerPitch * 100).toInt()}%)",
                    color = Color(0xFFCBD5E1),
                    fontSize = 13.sp
                )
                Slider(
                    value = speakerPitch,
                    onValueChange = {
                        voiceSpeaker.setPitch(it)
                        preferences.setPitch(it)
                        onUpdateConfig()
                    },
                    valueRange = 0.8f..1.8f,
                    colors = SliderDefaults.colors(
                        thumbColor = ElectricMagenta,
                        activeTrackColor = ElectricMagenta,
                        inactiveTrackColor = Color(0xFF334155)
                    ),
                    modifier = Modifier.testTag("voice_pitch_slider")
                )

                // Speed Slider
                Text(
                    text = "Bolne ki Speed: ${(speakerRate * 100).toInt()}%",
                    color = Color(0xFFCBD5E1),
                    fontSize = 13.sp
                )
                Slider(
                    value = speakerRate,
                    onValueChange = {
                        voiceSpeaker.setSpeechRate(it)
                        preferences.setSpeechRate(it)
                        onUpdateConfig()
                    },
                    valueRange = 0.7f..1.5f,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonCyan,
                        inactiveTrackColor = Color(0xFF334155)
                    ),
                    modifier = Modifier.testTag("voice_speed_slider")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        voiceSpeaker.speak("Namaste! Main Sia hoon, aapki pyari personal AI voice assistant. Main aapki har baat sunungi aur aapke liye sab kuch karungi!")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("test_female_voice_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF4C1D95)
                    )
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isSpeaking) "Sia Bol Rahi Hai... 🔊" else "Test Ladki Voice (Sun Kar Dekhein)",
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Live In-App Voice Chat Playground
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .testTag("voice_chat_playground_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = Brush.linearGradient(listOf(NeonCyan, ElectricMagenta)),
                width = 1.dp
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "In-App Voice Test Playground",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "Yahan tap karke Sia se baat karke dekhein",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Pulsing Mic Button
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(
                            if (inAppListening) Brush.radialGradient(
                                listOf(NeonCyan, Color(0xFF0284C7))
                            ) else Brush.radialGradient(
                                listOf(ElectricMagenta, Color(0xFF7C3AED))
                            )
                        )
                        .clickable {
                            if (inAppListening) {
                                voiceRecognizer.stopListening()
                                inAppListening = false
                            } else {
                                voiceSpeaker.stop()
                                inAppListening = true
                                voiceRecognizer.startListening()
                            }
                        }
                        .testTag("in_app_mic_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (inAppListening) Icons.Default.GraphicEq else Icons.Default.Mic,
                        contentDescription = "Speak",
                        tint = Color.White,
                        modifier = Modifier.size(38.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (inAppListening) "Sun rahi hoon... Boliye! 🎙️"
                    else if (isSpeaking) "Sia Bol Rahi Hai... 🔊"
                    else "Mic Par Tap Karke Boliye",
                    color = if (inAppListening) NeonCyan else Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Chat output box
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF1E293B))
                        .padding(12.dp)
                ) {
                    if (inAppUserPrompt.isNotBlank()) {
                        Text(
                            text = "Aapne bola: \"$inAppUserPrompt\"",
                            color = NeonCyan,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    Text(
                        text = "Sia: $inAppAiResponse",
                        color = Color.White,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Voice Commands Cheatsheet
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Aap Sia se kya kya karwa sakte hain? ⚡",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                CommandCategoryItem(
                    emoji = "💡",
                    title = "Device Controls",
                    examples = listOf("\"Torch on karo\"", "\"Torch band karo\"", "\"Kitne baje hain\"", "\"Aaj ki date\"")
                )

                CommandCategoryItem(
                    emoji = "📱",
                    title = "Apps Kholna",
                    examples = listOf("\"YouTube kholo\"", "\"WhatsApp kholo\"", "\"Camera kholo\"", "\"Calculator kholo\"")
                )

                CommandCategoryItem(
                    emoji = "🎵",
                    title = "YouTube Search & Play",
                    examples = listOf("\"YouTube par Arijit Singh ke gaane chalao\"", "\"Play party songs on YouTube\"")
                )

                CommandCategoryItem(
                    emoji = "❤️",
                    title = "Pyari Baatein & Masti",
                    examples = listOf("\"Kaise ho?\"", "\"Ek joke sunao\"", "\"Ek shayari sunao\"", "\"I love you / Meri tareef karo\"")
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun PermissionItem(
    title: String,
    subtitle: String,
    isGranted: Boolean,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF131D2D))
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isGranted) Color(0xFF34D399) else Color(0xFFFB7185),
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = subtitle,
                color = Color(0xFF94A3B8),
                fontSize = 11.sp
            )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Icon(
            imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint = if (isGranted) Color(0xFF10B981) else Color(0xFFF43F5E),
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun CommandCategoryItem(emoji: String, title: String, examples: List<String>) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 16.sp)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                color = Color(0xFF38BDF8),
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        examples.forEach { example ->
            Text(
                text = "• $example",
                color = Color(0xFFCBD5E1),
                fontSize = 12.sp,
                modifier = Modifier.padding(start = 22.dp, top = 2.dp)
            )
        }
    }
}
