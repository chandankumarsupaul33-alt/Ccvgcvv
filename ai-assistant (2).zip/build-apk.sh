#!/bin/bash
set -e

echo "=========================================="
echo "🚀 Building Sia AI Assistant APK..."
echo "=========================================="

# Create .env if not exists
touch .env
if [ -f .env.example ] && [ ! -s .env ]; then
    cp .env.example .env
fi

# Restore debug keystore if base64 exists
if [ -f debug.keystore.base64 ] && [ ! -f debug.keystore ]; then
    base64 -d debug.keystore.base64 > debug.keystore 2>/dev/null || true
fi

# Ensure executable permissions
chmod +x gradlew 2>/dev/null || true

# Run Gradle build
if [ -f ./gradlew ]; then
    ./gradlew assembleDebug --no-daemon
else
    gradle assembleDebug --no-daemon
fi

echo ""
echo "=========================================="
echo "✅ BUILD SUCCESSFUL!"
echo "Your APK is ready at: app/build/outputs/apk/debug/app-debug.apk"
echo "=========================================="
